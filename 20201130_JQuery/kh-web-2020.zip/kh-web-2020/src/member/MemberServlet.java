package member;

public class MemberServlet {

}
